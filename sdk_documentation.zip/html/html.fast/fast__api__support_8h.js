var fast__api__support_8h =
[
    [ "fast_read_register", "fast__api__support_8h_aa788ea4f82a6ce536b2d2854eb543792.html#aa788ea4f82a6ce536b2d2854eb543792", null ],
    [ "fast_write_register", "fast__api__support_8h_aa0991f2d172b2ffbfdbd1c3c449fcb67.html#aa0991f2d172b2ffbfdbd1c3c449fcb67", null ],
    [ "fast_config_file_read", "fast__api__support_8h_a3e3c550ac16d5f908e3fef8f0139a3d5.html#a3e3c550ac16d5f908e3fef8f0139a3d5", null ],
    [ "fast_toggle_ulpm_wake", "fast__api__support_8h_a5aee406fe9ade41b286e4f9c1feb5ed1.html#a5aee406fe9ade41b286e4f9c1feb5ed1", null ],
    [ "fast_sleep", "fast__api__support_8h_a3d3a1f99a1f346b7c4accf544740af18.html#a3d3a1f99a1f346b7c4accf544740af18", null ],
    [ "dbg_printf", "fast__api__support_8h.html#a6d26dbcf5cbf442c42ac03986edf8792", null ],
    [ "f_malloc", "fast__api__support_8h.html#aa762684863146bf3059c4889c6ab4eb6", null ],
    [ "f_free", "fast__api__support_8h.html#afb25f1ad1b20acd248bdc88b73b75013", null ]
];