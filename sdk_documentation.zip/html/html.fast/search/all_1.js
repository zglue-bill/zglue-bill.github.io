var searchData=
[
  ['chip_5fdescription',['chip_description',['../structfast__system__chips__information__s_a759936e2131e0680fbd91e82000137ef.html#a759936e2131e0680fbd91e82000137ef',1,'fast_system_chips_information_s']]],
  ['chip_5fdescriptor_5fsize',['CHIP_DESCRIPTOR_SIZE',['../fast__api_8h_a6e8e896ebe2a5ceb3afaddef0b6fa8af.html#a6e8e896ebe2a5ceb3afaddef0b6fa8af',1,'fast_api.h']]],
  ['chip_5fglobal_5fid',['chip_global_id',['../structfast__system__chips__information__s_ae07516306a8925f1cb1c1748380ddc2f.html#ae07516306a8925f1cb1c1748380ddc2f',1,'fast_system_chips_information_s']]],
  ['config_5ffile_5fid',['config_file_id',['../structfast__system__information__s_a0376281f917a246010b52253102775d0.html#a0376281f917a246010b52253102775d0',1,'fast_system_information_s']]],
  ['config_5ffile_5fversion',['config_file_version',['../structfast__system__information__s_afe8d7f7e43ff807ac62e1cd45a7a69fc.html#afe8d7f7e43ff807ac62e1cd45a7a69fc',1,'fast_system_information_s']]]
];
