var structfast__system__chips__information__s =
[
    [ "chip_global_id", "structfast__system__chips__information__s_ae07516306a8925f1cb1c1748380ddc2f.html#ae07516306a8925f1cb1c1748380ddc2f", null ],
    [ "chip_description", "structfast__system__chips__information__s_a759936e2131e0680fbd91e82000137ef.html#a759936e2131e0680fbd91e82000137ef", null ]
];