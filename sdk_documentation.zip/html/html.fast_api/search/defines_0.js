var searchData=
[
  ['chip_5fdescriptor_5fsize',['CHIP_DESCRIPTOR_SIZE',['../fast__api_8h.html#a6e8e896ebe2a5ceb3afaddef0b6fa8af',1,'fast_api.h']]]
];
