var searchData=
[
  ['data_5fuint16_5ft',['data_uint16_t',['../unionfast__gpio__interrupt__status__u.html#ab7746b9f2c8daf6d11614202b4976ddf',1,'fast_gpio_interrupt_status_u::data_uint16_t()'],['../unionfast__fault__status__mask__u.html#ab7746b9f2c8daf6d11614202b4976ddf',1,'fast_fault_status_mask_u::data_uint16_t()']]],
  ['data_5fuint8_5ft',['data_uint8_t',['../unionfast__led__mask__u.html#aedad89b3670e41cccaa282ee3b5378b7',1,'fast_led_mask_u::data_uint8_t()'],['../unionfast__ldo__mask__u.html#aedad89b3670e41cccaa282ee3b5378b7',1,'fast_ldo_mask_u::data_uint8_t()']]]
];
