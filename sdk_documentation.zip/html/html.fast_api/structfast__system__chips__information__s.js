var structfast__system__chips__information__s =
[
    [ "chip_global_id", "structfast__system__chips__information__s.html#ae07516306a8925f1cb1c1748380ddc2f", null ],
    [ "chip_description", "structfast__system__chips__information__s.html#a759936e2131e0680fbd91e82000137ef", null ]
];