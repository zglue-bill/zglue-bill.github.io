var structfast__system__information__s =
[
    [ "config_file_id", "structfast__system__information__s.html#a0376281f917a246010b52253102775d0", null ],
    [ "config_file_version", "structfast__system__information__s.html#afe8d7f7e43ff807ac62e1cd45a7a69fc", null ],
    [ "number_of_chiplets_on_fast", "structfast__system__information__s.html#af292440512c601d456b84f356ade22e0", null ],
    [ "supported_zeus", "structfast__system__information__s.html#a68d9f75e33af7244390e64dcbc649682", null ]
];