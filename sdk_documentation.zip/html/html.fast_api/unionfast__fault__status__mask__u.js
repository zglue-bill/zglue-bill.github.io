var unionfast__fault__status__mask__u =
[
    [ "thermal_alarm_trig", "unionfast__fault__status__mask__u.html#a56c005f8ae29868949a12b6235b4a197", null ],
    [ "boost_uvlo_trig", "unionfast__fault__status__mask__u.html#aa54bfc99e7f8a64b9f20ae8a42789fa1", null ],
    [ "boost_ilim_trig", "unionfast__fault__status__mask__u.html#a8c2a704f56ee9ff7eec018732e1e0019", null ],
    [ "vrail3_ovc_trig", "unionfast__fault__status__mask__u.html#a2609e37ad59d5b93a6429d727fb3ed43", null ],
    [ "vrail2_ovc_trig", "unionfast__fault__status__mask__u.html#ae3465c85a5fa0eace7d60e5ce857db5e", null ],
    [ "vrail1_ovc_trig", "unionfast__fault__status__mask__u.html#af8120360ad5734dec2c6a8ae3f2cd678", null ],
    [ "hvldo_ovc_trig", "unionfast__fault__status__mask__u.html#a3969fb41031636338f142be9ff5d11c9", null ],
    [ "reserved", "unionfast__fault__status__mask__u.html#a5a6ed8c04a3db86066924b1a1bf4dad3", null ],
    [ "mbits", "unionfast__fault__status__mask__u.html#a7c7ecca3ef5afc6e33ae82ec4e08a407", null ],
    [ "data_uint16_t", "unionfast__fault__status__mask__u.html#ab7746b9f2c8daf6d11614202b4976ddf", null ]
];