var unionfast__ldo__mask__u =
[
    [ "fast_ldo1", "unionfast__ldo__mask__u.html#a590ce4f6ad353f1b1e73c36cef584997", null ],
    [ "fast_ldo2", "unionfast__ldo__mask__u.html#a53f7f92b88332d751ade95d6b3cac7ea", null ],
    [ "fast_ldo3", "unionfast__ldo__mask__u.html#a915b936bd5cd4ce630331acd4b1fad85", null ],
    [ "reserved", "unionfast__ldo__mask__u.html#acb7bc06bed6f6408d719334fc41698c7", null ],
    [ "mbits", "unionfast__ldo__mask__u.html#a8dda74e6cad9546ac30643d367807eb8", null ],
    [ "data_uint8_t", "unionfast__ldo__mask__u.html#aedad89b3670e41cccaa282ee3b5378b7", null ]
];