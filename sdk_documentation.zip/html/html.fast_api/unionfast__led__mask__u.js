var unionfast__led__mask__u =
[
    [ "fast_led1", "unionfast__led__mask__u.html#ad78d4a70c703843e5a895088b7a3f991", null ],
    [ "fast_led2", "unionfast__led__mask__u.html#aca92cbbc64e6d3978e446edd33ddcb76", null ],
    [ "fast_led3", "unionfast__led__mask__u.html#a3f4fc9a3899beda7bcd99b74bb53a55a", null ],
    [ "reserved", "unionfast__led__mask__u.html#acb7bc06bed6f6408d719334fc41698c7", null ],
    [ "mbits", "unionfast__led__mask__u.html#ab31bea5f40fdcc96e1533bd637e31e31", null ],
    [ "data_uint8_t", "unionfast__led__mask__u.html#aedad89b3670e41cccaa282ee3b5378b7", null ]
];