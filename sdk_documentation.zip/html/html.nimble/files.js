var files =
[
    [ "ble_gap.c", "ble__gap_8c_source.html", null ],
    [ "ble_gatts.c", "ble__gatts_8c_source.html", null ]
];