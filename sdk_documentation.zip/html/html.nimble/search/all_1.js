var searchData=
[
  ['connectable',['connectable',['../structble__gap__slave__state_ac4e7bae47e0afd2e7338d7b324ace0ad.html#ac4e7bae47e0afd2e7338d7b324ace0ad',1,'ble_gap_slave_state']]]
];
