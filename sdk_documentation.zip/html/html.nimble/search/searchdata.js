var indexSectionsWithContent =
{
  0: "bcp",
  1: "b",
  2: "cp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Variables"
};

