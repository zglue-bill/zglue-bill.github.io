var searchData=
[
  ['preempted_5fop',['preempted_op',['../structble__gap__master__state_a8a7911091150f92f3347b653d5b57f4b.html#a8a7911091150f92f3347b653d5b57f4b',1,'ble_gap_master_state']]]
];
