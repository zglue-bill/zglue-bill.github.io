var searchData=
[
  ['nimble_20api',['NimBLE API',['../BLE2.html',1,'']]],
  ['nimble_20data_20structures',['Nimble Data Structures',['../BLE3.html',1,'']]],
  ['number_5fof_5fchiplets_5fon_5ffast',['number_of_chiplets_on_fast',['.././html.fast_api/structfast__system__information__s.html#af292440512c601d456b84f356ade22e0',1,'fast_system_information_s']]]
];
