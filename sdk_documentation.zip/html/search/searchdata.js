var indexSectionsWithContent =
{
  0: "bcdfhmnprstv",
  1: "f",
  2: "f",
  3: "bcdfhmnprstv",
  4: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Variables",
  4: "Pages"
};

